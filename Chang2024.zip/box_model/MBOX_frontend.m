%%%%%% change land OC burial; oxidw

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Define parameters   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


initialvalue = readtable('rawoutput1.xlsx','sheet',1);
initialvalue = table2array(initialvalue);

pars.Ageinj = (xlsread('driver.xlsx',1,"A:A") + 555)*1e6;
pars.CO2inj = xlsread('driver.xlsx',1,"B:B")*1e12;
AgeSrdata = xlsread('Sr_data_final.xlsx',1,"B:B");
Srisodata = xlsread('Sr_data_final.xlsx',1,"C:C");


for i=1:10;
    try

%%%%%%% set up global structures
global stepnumber
global pars
global workingstate

rng('shuffle'); % seed with the current time
rngState = rng; % current state of rng

%rng(job_number);
%rngState2 = rng;

%%% including position in the process queue
deltaSeed = uint32(feature('getpid'));
seed = rngState.Seed + deltaSeed;
rng(seed); % set the rng to use the modified seed


pars.ranc_inj = 0.85 + rand(1,1)*0.3;

%%%%%% water reservoir sizes in m3 (m=margins, s=surface, h= hi-lat, d=deep)
pars.vol_p  = 2.6e15 ;  %%%% approx volume of all shelves and slope to depth 100m, area pecentage 5%
pars.vol_di = 5.4e15 ;  %%%% approx volume of all shelves and slope in depth 100-1000m, area pecentage 5%
pars.vol_s  = 2.75e16 ; %%%% approx volume of suface water to depth 100m, area pecentage 76.5%
pars.vol_h  = 1.22e16 ; %%%% approx volume of hi-lat to depth 250m, area pecentage 13.5%
pars.vol_d  = 1.35e18 ;
pars.vol_ocean = pars.vol_p + pars.vol_di + pars.vol_s + pars.vol_h + pars.vol_d ;


%%%% mixing coefficient (Sv)
pars.mixcoeff_dip = 30.28;
pars.mixcoeff_ds  = 46.33;
pars.mixcoeff_dh  = 54.9;


%%%%%% inorganic carbon reservoirs in moles C
pars.CO2_a_0  = 5e16 ;
pars.DIC_p_0  = 5.2e15 ;
pars.DIC_di_0 = 1.08e16 ;
pars.DIC_s_0  = 5.37e16 ;
pars.DIC_h_0  = 2.71e16 ;
pars.DIC_d_0  = 3e18 ;
pars.ALK_p_0  = 5.2e15 ;
pars.ALK_di_0 = 1.08e16 ;
pars.ALK_s_0  = 5.37e16 ;
pars.ALK_h_0  = 2.71e16 ;
pars.ALK_d_0  = 3e18 ;



%%%%%% C isotope composition
pars.d13c_atm_0    = -7 ;
pars.d13c_DIC_p_0  = 0.1 ;
pars.d13c_DIC_di_0 = 0.1 ;
pars.d13c_DIC_s_0  = 0.1 ;
pars.d13c_DIC_h_0  = 0.1 ;
pars.d13c_DIC_d_0  = 0.1 ;

%%%%%% POC reservoirs in moles C
pars.POC_p_0  = 630e12 ;
pars.POC_di_0 = 250e12 ;
pars.POC_s_0  = 2329e12 ;
pars.POC_h_0  = 1084e12 ;
pars.POC_d_0  = 56000e12 ;


%%%%%% Dissolved phosphate in moles
pars.DP_p_0  = 1.82e12 ;
pars.DP_di_0 = 7.56e12 ;
pars.DP_s_0  = 0.55e12 ;
pars.DP_h_0  = 16.27e12 ;
pars.DP_d_0  = 2970e12 ;


pars.d13c_POC_p_0  = -26;
pars.d13c_POC_di_0 = -26;
pars.d13c_POC_s_0  = -26 ;
pars.d13c_POC_h_0  = -26 ;
pars.d13c_POC_d_0  = -26 ;


%%%%%% initial amount of O2 in moles C
pars.O2_a_0  = 3.7e19 ;
pars.O2_p_0  = 6.705e14 ;
pars.O2_di_0 = 8.964e14 ;
pars.O2_s_0  = 9.139e15 ;
pars.O2_h_0  = 4.02e15 ;
pars.O2_d_0  = 1.823e17 ;


%%%%%% initial amount of FeIII in moles
pars.FeIII_p_0  = 1.56e9 ;
pars.FeIII_di_0 = 3.24e9 ;
pars.FeIII_s_0  = 9.625e9 ;
pars.FeIII_h_0  = 3.66e9 ;
pars.FeIII_d_0  = 810e9 ;

%%%%%% initial amount of sulfate in moles

pars.SO4_p_0  = 7.28e16;
pars.SO4_di_0 = 1.512e17;
pars.SO4_s_0  = 7.7e17;
pars.SO4_h_0  = 3.416e17;
pars.SO4_d_0  = 3.78e19;

%%%%%% initial amount of FeII in moles
pars.FeII_p_0  = 0;
pars.FeII_di_0 = 0;
pars.FeII_s_0  = 0;
pars.FeII_h_0  = 0;
pars.FeII_d_0  = 0;

%%%%%% initial amount of H2S in moles
pars.H2S_p_0  = 0;
pars.H2S_di_0 = 0;
pars.H2S_s_0  = 0;
pars.H2S_h_0  = 0;
pars.H2S_d_0  = 0;

%%%%%% initial amount of Sr in moles and its isotope
pars.OSr0 = 1.2e17;
pars.deltaSrocean0 = 0.7088;

%%%%%% present day rates
pars.k_ccdeg = 6.7e12 ; %8e12 7.5e12
pars.k_carbw = 12e12 ;
pars.k_sfw = 0 ; %%% Seafloor weathering
pars.k_mccb =  20e12; %pars.k_carbw + pars.k_ccdeg - pars.k_sfw; 
pars.k_silw = pars.k_mccb - pars.k_carbw ;
basfrac = 0.3 ;
pars.k_granw = pars.k_silw * (1-basfrac) ;
pars.k_basw = pars.k_silw * basfrac ;

%%%%%% organic C cycle
pars.k_ocdeg = 1.25e12 ;
pars.k_locb = 0 ;%2.5e12
pars.k_mocb = 7e12  ;
pars.k_oxidw = pars.k_mocb + pars.k_locb - pars.k_ocdeg ;

%%%%%% present P, Fe, pyrite and sulfate weathering rate
pars.k_phosw = 0.0967e12;
pars.k_FeIIIw = 2e9;
pars.k_pyritew = 1.85e12;
pars.k_sulfatew = 1.25e12;

%%%%%% present pyrite and sulfate burial rate
pars.k_pyriteb_p  = 1.4e12;
pars.k_pyriteb_di = 0.45e12;
pars.k_sulfateb   = 1.25e12;

%%%%%% Redfeild ratio
pars.Red_C_P = 106;
pars.Red_C_N = 106/16;
pars.Red_C_O = 106/138;
pars.Red_C_Fe = 106*2000;
pars.Red_Fe_P = pars.Red_C_P/pars.Red_C_Fe;

pars.BE_p  = 6/40;
pars.BE_di = 6/40;
pars.BE_d  = 1/10;
%%%%%% Monod constant; mol/m3
pars.KP = 0.1e-3;
pars.KFe = 0.1e-6;
pars.KmO2 = 8e-3;  %%%8e-3
pars.KmFeIII = 10;

%%%%%% reaction rate constant m3 mol-1 yr-1
pars.kpy = 0.3708/1e3*24*365.25;
pars.kironO = 1.4e5;
pars.ksulfO = 1.6e2; %%%1.6e2
pars.kSironR = 8;
pars.kSide = 4e3; %%%mol m-3 yr-1

%%%%%% Ksp
pars.Kspside = 10^(-8.4)*1e6;%%%mol2 m-6
pars.KspFeSaq = 10^(-5.08)*1e3;%%%mol m-3
pars.STFeSaq = 10^(-5.7)*1e3;%%%mol m-3
pars.FeIIIa_s = 1.443e9; %%%
pars.FeIIIa_h = 0;  %%%% 0.00795e9
pars.FeIIhydro = 13.5e9;


%%%%%Sr parameters
pars.FSr_riv = 22e9; %47.6e9
pars.FSr_hT= 8.4e9;
pars.FSr_lT= 10e9;
pars.FSr_dia= 3.4e9;
pars.kcarbSr= 5.783333e-07;
pars.Sriso_riv= 0.71107;
pars.Sriso_hT= 0.7037;
pars.Sriso_lT= 0.7084;
pars.Srdelta_dia= - 0.00075;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Initialise   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% set maximum step size for solver
options = odeset('maxstep',1e3,'NonNegative',[1:11 18:27 33:60]) ;

%%%% run beginning
fprintf('Beginning run: \n')

%%%% set stepnumber to 1
stepnumber = 1 ;

%%%%%%% model timeframe in years (0 = present day)
pars.whenstart = -20e6 ;
pars.whenend = 60e6 ;

%%%% model start state
pars.startstate(1) = initialvalue(1);
pars.startstate(2) = initialvalue(2);
pars.startstate(3) = initialvalue(3);
pars.startstate(4) = initialvalue(4);
pars.startstate(5) = initialvalue(5);
pars.startstate(6) = initialvalue(6);

pars.startstate(7) = initialvalue(7);
pars.startstate(8) = initialvalue(8);
pars.startstate(9) = initialvalue(9);
pars.startstate(10) = initialvalue(10);
pars.startstate(11) = initialvalue(11);

pars.startstate(12) = initialvalue(12);
pars.startstate(13) = initialvalue(13);
pars.startstate(14) = initialvalue(14);
pars.startstate(15) = initialvalue(15);
pars.startstate(16) = initialvalue(16);

pars.startstate(17) = initialvalue(17);
pars.startstate(18) = initialvalue(18);
pars.startstate(19) = initialvalue(19);
pars.startstate(20) = initialvalue(20);
pars.startstate(21) = initialvalue(21);

pars.startstate(22) = initialvalue(22);
pars.startstate(23) = initialvalue(23);
pars.startstate(24) = initialvalue(24);
pars.startstate(25) = initialvalue(25);
pars.startstate(26) = initialvalue(26);
pars.startstate(27) = initialvalue(27);

pars.startstate(28) = initialvalue(28);
pars.startstate(29) = initialvalue(29);
pars.startstate(30) = initialvalue(30);
pars.startstate(31) = initialvalue(31);
pars.startstate(32) = initialvalue(32);

pars.startstate(33) = initialvalue(33);
pars.startstate(34) = initialvalue(34);
pars.startstate(35) = initialvalue(35);
pars.startstate(36) = initialvalue(36);
pars.startstate(37) = initialvalue(37);

pars.startstate(38) = initialvalue(38);
pars.startstate(39) = initialvalue(39);
pars.startstate(40) = initialvalue(40);
pars.startstate(41) = initialvalue(41);
pars.startstate(42) = initialvalue(42);

pars.startstate(43) = initialvalue(43);
pars.startstate(44) = initialvalue(44);
pars.startstate(45) = initialvalue(45);
pars.startstate(46) = initialvalue(46);
pars.startstate(47) = initialvalue(47);

pars.startstate(48) = initialvalue(48);
pars.startstate(49) = initialvalue(49);

pars.startstate(50) = initialvalue(50);
pars.startstate(51) = initialvalue(51);
pars.startstate(52) = initialvalue(52);
pars.startstate(53) = initialvalue(53);

pars.startstate(54) = initialvalue(54);
pars.startstate(55) = initialvalue(55);
pars.startstate(56) = initialvalue(56);
pars.startstate(57) = initialvalue(57);
pars.startstate(58) = initialvalue(58);
pars.startstate(59) = pars.OSr0;
pars.startstate(60) = pars.OSr0*pars.deltaSrocean0;

%%%%%%% run the system 
tspan = linspace(pars.whenstart,pars.whenend,3200);
[rawoutput.T,rawoutput.Y] = ode15s(@MBOX_equations,tspan,pars.startstate,options);

%%%%% start time counter
tic



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Postprocessing   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% takes 'workingstate' from model and turns into 'state' %%%%%%%

%%%% size of output 
pars.output_length = length(rawoutput.T) ;
%%%%%%%%%% model finished output to screen
fprintf('Integration finished \t') ; fprintf('Total steps: %d \t' , stepnumber ) ; fprintf('Output steps: %d \n' , pars.output_length ) 
toc

%%%%%%%%% print final model states using final state for each timepoint
%%%%%%%%% during integration
fprintf('assembling state vectors... \t')
tic

%%%% trecords is index of shared values between ode15s output T vector and
%%%% model recorded workingstate t vector
[sharedvals,trecords] = intersect(workingstate.time,rawoutput.T,'stable') ;


%%%%%% done message
fprintf('Done: ')
endtime = toc ;
fprintf('time (s): %d \n', endtime )



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%   Plotting script   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
time_myr = rawoutput.T'/1e6-555;
save('resultstime.ascii','time_myr','-ascii','-append','-tabs');

ccdegf = interp1(pars.Ageinj,pars.CO2inj,rawoutput.T') * pars.ranc_inj;
save('resultsccdegf.ascii','ccdegf','-ascii','-append','-tabs');


CO2f = rawoutput.Y(:,1)/pars.CO2_a_0;
CO2f = CO2f';
save('resultsCO2f.ascii','CO2f','-ascii','-append','-tabs');

Sr_isof = rawoutput.Y(:,60)./rawoutput.Y(:,59);
Sr_isof = Sr_isof';
save('resultsSr_isof.ascii','Sr_isof','-ascii','-append','-tabs');


catch MException
    disp(MException)
continue
    end
end





