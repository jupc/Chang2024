%%%% load data
Agedata = xlsread('Sr_CO2data.xlsx',1,"A:A");
Srdata = xlsread('Sr_CO2data.xlsx',1,"D:D");

AgeCO2 = xlsread('Sr_CO2data.xlsx',1,"E:E");
CO2data = xlsread('Sr_CO2data.xlsx',1,"F:F");
CO2datal = xlsread('Sr_CO2data.xlsx',1,"G:G");
CO2datah = xlsread('Sr_CO2data.xlsx',1,"H:H");

AgeSrdata = xlsread('Sr_data_final.xlsx',1,"B:B");
Srisodata = xlsread('Sr_data_final.xlsx',1,"C:C");
%%%%%%%%%%%%%%%%%%%%%222222222222%%%%%%%%%%%%%%%%%%%%%%%%
resultspO2 = dlmread('resultsCO2f.ascii');
time = -dlmread('resultstime.ascii');
time = time(:,600:end);
resultspO2 = resultspO2(:,600:end);

resultspO2l = resultspO2;
resultspO2_mean = mean(resultspO2l,1);
time_mean = mean(time,1);


mymap = [255 255 255
    251 227 201
    243 198 155
    240 182 130
    237 166 114
    230 141 90
    222 101 55
    192 86 52
    145 70 43
    108 54 30 ]/255;

% Generate sample data
x = time(:);
y = resultspO2(:);


% Calculate data density using hist3
xnbins = 100; % Number of bins for histogram
ynbins = 10; % Number of bins for histogram
[N, edges] = hist3([y x], [ynbins xnbins]);
density = N / sum(N(:));

% Define the range of values for x and y axes
x_range = linspace(min(x), max(x), xnbins);
y_range = linspace(min(y), max(y), ynbins);
[X, Y] = meshgrid(x_range, y_range);

% Plot the density contour
subplot(3,1,2);
hold on
box on;
contourf(X, Y, density, 'LineStyle', 'none')
%colorbar % Add colorbar for reference
xlabel('Age (Ma)');
ylabel('\it{p}\rmCO_2 (PAL)');
title('b');
%ylim([-3.5 0.5]);
xlim([500 560]);
set(gca,'XDir','reverse')
% Customize the plot appearance (optional)
colormap(mymap)% Change the color map
plot(time_mean ,resultspO2_mean,'color',[0 0 0],'LineWidth',2);
for i = 1:7
plot([AgeCO2(i), AgeCO2(i)], [CO2datal(i),CO2datah(i)], '-','LineWidth',5,'color',[152 183 219]/255);
end
plot(AgeCO2,CO2data,'o','MarkerFaceColor',[7 6 200]/255,'MarkerEdgeColor',[1 1 1],'MarkerSize',5);
%set(gca, 'XDir', 'reverse');
set(gca, 'Layer','top');
colorbarHandle = colorbar;
bartitle = title(colorbarHandle, 'Density');
Position_Bartitle = get(bartitle, 'Position');
Position_Bartitle = Position_Bartitle + [8  115 10];    % move to the up [8  115  10]     
set(bartitle, 'Position',Position_Bartitle);
hold off


%%%%%%%%%%%%%%%%%%%%%333333333333%%%%%%%%%%%%%%%%%%%%%%%%



resultspO2 = dlmread('resultsSr_isof.ascii');
time = -dlmread('resultstime.ascii');
time = time(:,600:end);
resultspO2 = resultspO2(:,600:end);
resultspO2l = resultspO2;
resultspO2_mean = mean(resultspO2l,1);
time_mean = mean(time,1);

% Generate sample data
x = time(:);
y = resultspO2(:);


% Calculate data density using hist3

[N, edges] = hist3([y x], [ynbins xnbins]);
density = N / sum(N(:));

% Define the range of values for x and y axes
x_range = linspace(min(x), max(x), xnbins);
y_range = linspace(min(y), max(y), ynbins);
[X, Y] = meshgrid(x_range, y_range);

% Plot the density contour
subplot(3,1,3);
hold on
box on;
contourf(X, Y, density, 'LineStyle', 'none');
%colorbar % Add colorbar for reference
xlabel('Age (Ma)');
ylabel('Seawater ^8^7Sr/^8^6Sr');
title('c');
%ylim([-3.5 0.5]);
xlim([500 560]);
set(gca,'XDir','reverse')
% Customize the plot appearance (optional)
%colormap(mymap);% Change the color map
plot(time_mean ,resultspO2_mean,'color',[0 0 0],'LineWidth',2);
plot(AgeSrdata,Srisodata,'.','color',[80 80 80]/255,'MarkerSize',10);
%set(gca, 'XDir', 'reverse');
set(gca, 'Layer','top');
colorbarHandle = colorbar;
bartitle = title(colorbarHandle, 'Density');
Position_Bartitle = get(bartitle, 'Position');
Position_Bartitle = Position_Bartitle + [8  115 10];    % move to the up [8  115  10]     
set(bartitle, 'Position',Position_Bartitle);
hold off


%%%%%%%%%%%%%%%%%%%%%11111111111%%%%%%%%%%%%%%%%%%%%%%%%



resultspO2 = dlmread('resultsccdegf.ascii')/6.7e12;
time = -dlmread('resultstime.ascii');
time = time(:,600:end);
resultspO2 = resultspO2(:,600:end);
resultspO2l = resultspO2;
resultspO2_mean = mean(resultspO2l,1);
time_mean = mean(time,1);

% Generate sample data
x = time(:);
y = resultspO2(:);


% Calculate data density using hist3
%xnbins = 200; % Number of bins for histogram
%ynbins = 15; % Number of bins for histogram
[N, edges] = hist3([y x], [ynbins xnbins]);
density = N / sum(N(:));

% Define the range of values for x and y axes
x_range = linspace(min(x), max(x), xnbins);
y_range = linspace(min(y), max(y), ynbins);
[X, Y] = meshgrid(x_range, y_range);

% Plot the density contour
subplot(3,1,1);
hold on
box on;
contourf(X, Y, density, 'LineStyle', 'none');
%colorbar % Add colorbar for reference
xlabel('Age (Ma)');
ylabel([sprintf('Mid-ridge spreading rate\n(× background)')]);
title('a');
%ylim([-3.5 0.5]);
xlim([500 560]);
set(gca,'XDir','reverse')
% Customize the plot appearance (optional)
%colormap(mymap);% Change the color map
plot(time_mean ,resultspO2_mean,'color',[0 0 0],'LineWidth',2);
%set(gca, 'XDir', 'reverse');
set(gca, 'Layer','top');
colorbarHandle = colorbar;
bartitle = title(colorbarHandle, 'Density');
Position_Bartitle = get(bartitle, 'Position');
Position_Bartitle = Position_Bartitle + [8  115 10];    % move to the up [8  115  10]
set(bartitle, 'Position',Position_Bartitle);
hold off




