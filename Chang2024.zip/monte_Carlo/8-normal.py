import numpy as np
import matplotlib.pyplot as plt

# 定义函数1：k0 = exp(9345.17/T − 60.2409 + 23.3585 ln(T/100) + S/1000*[0.023517 − 0.00023656T + 0.0047036 (T/100)2])
def function1(T, S):
    k0 = np.exp(9345.17/(T + 273) - 60.2409 + 23.3585*np.log((T + 273)/100) + S/1000*(0.023517 - 0.00023656*(T + 273) + 0.0047036*((T + 273)/100)**2))
    return k0

# 定义函数2：ɛp = δ13Ccarb − δ13Corg + Δ13Calgae + Δ2 –(9866/(T+273)−24.12-1.2)
def function2(δ13Ccarb, δ13Corg, Δ13Calgae, Δ2, T):
    ɛp = δ13Ccarb - δ13Corg + Δ13Calgae + Δ2 - (9866/(T+273) - 24.12 - 1.2)
    return ɛp

# 定义函数3：PCO2 = b / [(26.5 − ɛp)*k0]，ɛp=26.5-28才对
def function3(b, ɛp, k0):
    PCO2 = b / ((26.5 - ɛp) * k0)
    return PCO2

# 取样次数
num_samples = 20000000
# 设置参数范围和分布方式
δ13Ccarb_mean, δ13Ccarb_std = -7.1, 0.4
δ13Corg_mean, δ13Corg_std = -35.5, 2.3
S_mean, S_std = 40, 2
T_mean, T_std = 29, 2

Δ2_mean, Δ2_std = 1.5, 0.1 #不变
b_mean, b_std = 170, 30 #不变
Δ13Calgae_mean, Δ13Calgae_std = 0.6, 0.1 #不变


# 生成参数样本
T_samples = np.random.normal(T_mean, T_std, num_samples)
S_samples = np.random.normal(S_mean, S_std, num_samples)
δ13Ccarb_samples = np.random.normal(δ13Ccarb_mean, δ13Ccarb_std, num_samples)
δ13Corg_samples = np.random.normal(δ13Corg_mean, δ13Corg_std, num_samples)
Δ2_samples = np.random.normal(Δ2_mean, Δ2_std, num_samples)
b_samples = np.random.normal(b_mean, b_std, num_samples)
Δ13Calgae_samples = np.random.normal(Δ13Calgae_mean, Δ13Calgae_std, num_samples)


# 计算函数1的结果
k0_samples = function1(T_samples, S_samples)

# 计算函数2的结果
ɛp_samples = function2(δ13Ccarb_samples, δ13Corg_samples, Δ13Calgae_samples, Δ2_samples, T_samples)

# #取值正态
# ɛp_mean = np.mean(ɛp_samples)
# ɛp_std = np.std(ɛp_samples)
# ɛp_samples_2st = np.random.normal(ɛp_mean, 2*ɛp_std, num_samples)


# 计算函数3的结果
PCO2_samples = function3(b_samples, ɛp_samples, k0_samples)

# 将大于20000的值替换为20000,小于0的值替换为0
PCO2_samples = np.where(PCO2_samples > 20000, 20000, PCO2_samples)
PCO2_samples = np.where(PCO2_samples < 0, 0, PCO2_samples)

# 计算并打印中位数和68%置信区间
k0_median = np.median(k0_samples)
k0_CI = np.percentile(k0_samples, [16, 84])
print("k0 Median:", k0_median)
print("k0 68% Confidence Interval:", k0_CI)

ɛp_median = np.median(ɛp_samples)
ɛp_CI = np.percentile(ɛp_samples, [16, 84])
print("ɛp Median:", ɛp_median)
print("ɛp 68% Confidence Interval:", ɛp_CI)

PCO2_median = np.median(PCO2_samples)
PCO2_CI = np.percentile(PCO2_samples, [16, 84])
print("PCO2 Median:", PCO2_median)
print("PCO2 68% Confidence Interval:", PCO2_CI)

# 绘制概率分布图
plt.figure(figsize=(12, 4))

plt.subplot(1, 3, 1)
plt.hist(k0_samples, bins=1000, density=True, alpha=0.7, color='blue')
plt.xlabel('k0')
plt.ylabel('Probability Density')
plt.title('Probability Distribution of k0')

plt.subplot(1, 3, 2)
plt.hist(ɛp_samples, bins=1000, density=True, alpha=0.7, color='green')
plt.xlabel('ɛp')
plt.ylabel('Probability Density')
plt.title('Probability Distribution of ɛp')

plt.subplot(1, 3, 3)
plt.hist(PCO2_samples, bins=1000, density=True, alpha=0.7, color='red')
#限制x轴坐标范围
plt.xlim(-5000,15000)
plt.xlabel('PCO2')
plt.ylabel('Probability Density')
plt.title('Probability Distribution of PCO2')

plt.suptitle('Miaohe_ref', fontsize=16)  # 添加整个图的标题

plt.tight_layout()
plt.savefig('Miaohe_ref.png')
plt.close()